package demo1;

public class twoH extends Dog{
    @Override
    public void sleep() {
        System.out.println("我是2ha，我会睡觉");
    }

}
