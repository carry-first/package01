package demo1;

public abstract class Dog extends Animal{

    @Override
    public void eat() {
        System.out.println("我会吃东西");
    }
}
