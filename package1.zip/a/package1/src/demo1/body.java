package demo1;

public class body {
    public static void main(String[] args) {
        twoH th = new twoH();
        th.sleep();
        th.eat();
        xuediao xd = new xuediao();
        xd.sleep();
        xd.eat();
    }
}
