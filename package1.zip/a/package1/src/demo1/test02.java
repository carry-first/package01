package demo1;

public interface test02 {
    public static void method01(){

    }
    private void method02(){};

}

