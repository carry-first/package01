package demo1;

public abstract class Animal {
    public abstract void eat();
    public abstract void sleep();
}
