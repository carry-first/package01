package demo1;

public class xuediao extends Dog{
    @Override
    public void sleep() {
        System.out.println("我是雪雕狗，我会优雅的睡觉");
    }
}
