package com.FuctionalInterface.base.methodQuote;

@FunctionalInterface
public interface Fuction2 {
    public abstract void pri(String s);
}
