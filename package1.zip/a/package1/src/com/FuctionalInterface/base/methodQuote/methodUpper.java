package com.FuctionalInterface.base.methodQuote;

public class methodUpper {
    public String Upper(String s){
        return s.toUpperCase();
    }
}
