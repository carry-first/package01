package com.FuctionalInterface.base.methodQuote;

public interface Calcable {
    int calc(int n);
}
