package com.FuctionalInterface.base.use1;

import jdk.jfr.Name;

//  函数接口注解
//  用来检测是否包含函数接口的注解内容
@Name("Tang")
@FunctionalInterface
public interface Function1 {
    public abstract void method1();
}
