package com.FuctionalInterface.base.creatQuote;

public interface biuldPerson {
    Person builderPerson(String name);
}
