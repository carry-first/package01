package com.FuctionalInterface.base.creatQuote;

import java.util.Arrays;

public class arr {
    public static void main(String[] args) {
        int arr[] = new int[10];
        System.out.println(Arrays.toString(arr));
    }
}
