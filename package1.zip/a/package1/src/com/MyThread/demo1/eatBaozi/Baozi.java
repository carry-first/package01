package com.MyThread.demo1.eatBaozi;

public class Baozi {
    String pi;
    String xian;
    Boolean flag=false;
}
