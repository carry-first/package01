package com.review;

public interface Testinterface01 {
    abstract void eat();
    void sleep();
}
