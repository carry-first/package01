package com.review;

public class useimp {
    public static void main(String[] args) {
        Testinterface01 t = new impTest01();
        t.eat();
        t.sleep();
    }
}
