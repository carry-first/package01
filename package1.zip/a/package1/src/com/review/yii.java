package com.review;

public class yii {
    public static void main(String[] args) {
        System.out.println("jiojm");
    }
}
