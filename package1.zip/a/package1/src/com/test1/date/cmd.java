package com.test1.date;

import java.io.IOException;

public class cmd {
    public static void main(String[] args) throws IOException {
        Runtime run = Runtime.getRuntime();
        run.exec("shutdown -l");

    }
}
