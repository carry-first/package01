package com.test1.heroAttackInterface;

public interface skill {
//    释放技能
    void use();
}
