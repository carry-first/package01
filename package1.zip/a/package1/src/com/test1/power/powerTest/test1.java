package com.test1.power.powerTest;

import com.test1.power.power1;

public class test1 extends power1 {
    public void method(){
        System.out.println(super.num);
    }
}
