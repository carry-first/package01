package com.test1.power;

public class power1 {
    protected int num = 10;
    int c =10;
    public void content(){
        System.out.println(num);
    }
}
