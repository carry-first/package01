package com.test1.power;

public class power2 {
    public static void main(String[] args) {
        System.out.println(new power1().num);
    }
}
