package com.test1.implement;

public class implementMulti2 implements multiInterface{
    @Override
    public void eat() {
        System.out.println("第二个类的吃饭");
    }

    @Override
    public void sleep() {
        System.out.println("第二个类的睡觉");

    }
}
