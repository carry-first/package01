package com.test1.implement;

public interface MyFirstInterfaceMuster extends MyFirstInterface,MyFirstInterface2{


    @Override
    default void dm() {

    }


    @Override
    default void test() {

    }


    @Override
    default void methodDefault1() {

    }

    @Override
    default void methodDefault2() {

    }
}
