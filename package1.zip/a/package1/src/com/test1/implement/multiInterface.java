package com.test1.implement;
//定义接口
public interface multiInterface {
    public abstract void eat();
    public abstract void sleep();
}
