package com.test1.demo1;

public interface Myinterface1 {
    void eat();
}
