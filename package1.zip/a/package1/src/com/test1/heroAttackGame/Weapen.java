package com.test1.heroAttackGame;

public class Weapen {
    private String code;

    public Weapen(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
