package com.test1.bodyClass;

public class newLocalDemo {
    public static void main(String[] args) {
//        创建并调用方法
        localDemo ld = new localDemo();
        ld.methodLocalDemo();
    }
}
