package com.test1.exampleUsb;

public interface USB {
    public abstract void open();
    public abstract void close();
}
