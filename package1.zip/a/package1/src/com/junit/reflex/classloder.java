package com.junit.reflex;

public class classloder {
    public static void main(String[] args) {

    }
}
