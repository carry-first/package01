package com.junit.junit;

//定义测试类的测试内容方法
public class Caluctor {
//    返回两个参数的和
    public int add(int a,int b){
        return a+b;
    };
}
