
/**
 * @since 1.5
 * @author Tang A Biao
 * @version 1.0
 */

public class annonDemo1 {
    /**
     * 两数之和
     * @param a 整数
     * @param b 整数
     * @return  返回一个两数之和
     */
    public int add(int a,int b){
        return a + b;
    }
}
