package com.jpanel.demo1;

public class sss {
    public sss() {
    }
}