package com.jpanel.demo1;

import javax.swing.*;


public class first {
    private JPanel panel1;
    private JTextArea textArea1;
    private JButton clickButtonButton;
    private JPasswordField passwordField1;
    private JComboBox comboBox1;
    private JTextArea textArea2;

    private static void createUIComponents() {
        // TODO: place custom component creation code here

    }

    public static void main(String[] args) {
    }

    public void setData(sss data) {
    }

    public void getData(sss data) {
    }

    public boolean isModified(sss data) {
        return false;
    }
}
