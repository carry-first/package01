package com.jpanel.greedySnake;

public class panel {
}
