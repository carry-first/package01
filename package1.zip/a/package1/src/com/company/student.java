package com.company;

public class student {
    String name  ;
    int age;
    public student(String name,int age){
        this.name = name;
        this.age = age;
        System.out.println(this.name);
        System.out.println(this.age);
    }
    public  student(){
        System.out.println("空构造函数");
    };

}
