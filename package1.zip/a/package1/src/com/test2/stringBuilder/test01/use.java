package com.test2.stringBuilder.test01;

public class use {
    public static void main(String[] args) {
        fu fz = new zi();
        System.out.println(fz.getName());
        fz.method01();
        fz.method02();
        System.out.println(fz.name);
    }
}
