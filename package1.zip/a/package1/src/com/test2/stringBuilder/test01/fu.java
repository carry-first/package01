package com.test2.stringBuilder.test01;

public class fu {
    int name =10;
    public void method01(){
        System.out.println("父类方法01");
    }
    public void method02(){
        System.out.println("父类方法02");
    }
    public int getName(){
        return this.name;
    }
}
