package com.test2.stringBuilder.Generic;

public class Person {
}
