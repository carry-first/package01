package com.test2.stringBuilder.Generic;

public class implementsGeneric1 implements GenericInterface<String>{

    @Override
    public void method(String s) {
        System.out.println(s);
    }

    @Override
    public void method1(String s) {
        System.out.println(s);

    }

    @Override
    public void method2(String s) {
        System.out.println(s);

    }
}
