package com.test2.stringBuilder.Generic;

public interface GenericInterface<e> {
    public  void method(e s);
    public  void method1(e s);
    public  void method2(e s);
}
