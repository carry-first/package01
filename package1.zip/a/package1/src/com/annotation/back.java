package com.annotation;

public class back {
    public static void main(String[] args) {
        System.out.println("content");
    }
}
