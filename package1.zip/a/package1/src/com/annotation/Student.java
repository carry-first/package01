package com.annotation;

public class Student {
    public void sleep(){
        System.out.println("学生在睡觉");
    }
    public void dance(){
        System.out.println("学生在跳舞");
    }
}
