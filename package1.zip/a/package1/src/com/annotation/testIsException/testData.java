package com.annotation.testIsException;


public @interface testData {
}
