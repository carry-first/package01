package com.Executors.lambda;

public interface Cook {
    public void makeFood();
}
