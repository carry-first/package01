package com.Executors.lambda;

public interface calculatorItf {
    public int cal(int a ,int b);
}
