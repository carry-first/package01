package com.IOStream.readFile;

import java.io.IOException;

public class test {
    public static void main(String[] args) throws IOException {
        Runtime rt = Runtime.getRuntime();
        System.out.println(rt.totalMemory());
        System.out.println("end");
    }
}
