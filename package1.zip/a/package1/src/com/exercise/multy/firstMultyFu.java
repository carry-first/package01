package com.exercise.multy;

public class firstMultyFu {
    int num = 10;
    public void method (){
        System.out.println("父类方法");
    }
    public void getNum (){
        System.out.println(num);
    }
}
