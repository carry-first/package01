package com;

import javax.swing.*;

public class panel {
    public static void main(String[] args) {
        int b = JOptionPane.showConfirmDialog(null, "内容", "标题", JOptionPane.YES_OPTION);
//        System.out.println(b);
//        if(b == 0){
//            JOptionPane.showMessageDialog(null,"点击了是","tok",JOptionPane.PLAIN_MESSAGE);
//        }else{
//            JOptionPane.showMessageDialog(null,"点击了是","tok",JOptionPane.PLAIN_MESSAGE);
//        }
    }
}
