package com.HashMap;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class xintexing {
    public static void main(String[] args) {
        Set<String> s = Set.of("a","b","c","d");
        Map<Integer,String> map = Map.of(01,"e",02,"f",03,"g");
        List<Integer> list = List.of(12,43,21,54,23,65,32,74);
        System.out.println(s);
        System.out.println(map);
        System.out.println(list);
    }
}
