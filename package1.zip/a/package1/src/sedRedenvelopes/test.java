package sedRedenvelopes;

import java.util.Random;

public class test {
    public static void main(String[] args) {
        Random rm = new Random();
        System.out.println(rm.nextDouble());
    }
}
