package cn.tang.request;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/ServletDemo01")
public class ServletDemo01 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String method = request.getMethod();
        String contextPath = request.getContextPath();
        String servletPath = request.getServletPath();
        String requestURI = request.getRequestURI();
        String remoteAddr = request.getRemoteAddr();
        String protocol = request.getProtocol();
        StringBuffer requestURL = request.getRequestURL();
        System.out.println(method);
        System.out.println(contextPath);
        System.out.println(servletPath);
        System.out.println(remoteAddr);
        System.out.println(protocol);
        System.out.println(requestURI);
        System.out.println(requestURL);
    }
}
